import 'dart:io';
import 'package:flutter/foundation.dart';

class ApiConfig {
  static String get _baseUrl {
    if (kIsWeb) {
      // Web (Chrome, Firefox, etc.)
      return 'http://localhost:8080/api';
    } else if (Platform.isAndroid || Platform.isIOS) {
      // Para dispositivos físicos o emuladores móviles
      return '192.168.10.194'; // 👈 Reemplaza con la IP de tu PC en la red local
    } else {
      // Para escritorio (Windows, Mac, Linux)
      return 'http://localhost:8080/api';
    }
  }

  static String get loginEndpoint => '$_baseUrl/auth/login';
  static String get registerEndpoint => '$_baseUrl/auth/register';
  static String get librosEndpoint => '$_baseUrl/libros';
  static String get favoritosEndpoint => '$_baseUrl/favoritos';
}
