import 'libro.dart';

class Favorito {
  final Libro libro;

  Favorito({required this.libro});
}
