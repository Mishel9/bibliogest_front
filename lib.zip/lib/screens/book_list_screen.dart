import 'package:flutter/material.dart';

class BookListScreen extends StatelessWidget {
  const BookListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lista de Libros')),
      body: const Center(child: Text('Aquí se mostrará la lista de libros')),
    );
  }
}
