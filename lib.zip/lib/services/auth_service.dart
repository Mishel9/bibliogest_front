import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:bibliogestapp/config/api_config.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  Future<bool> register({
    required String nombre,
    required int edad,
    required String email,
    required String password,
    required String direccion,
    required String telefono,
  }) async {
    final url = Uri.parse(ApiConfig.registerEndpoint);

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'nombre': nombre,
        'edad': edad,
        'email': email,
        'password': password,
        'direccion': direccion,
        'telefono': telefono,
      }),
    );

    if (response.statusCode != 200) {
      print('Error en register: ${response.body}');
    }

    return response.statusCode == 200;
  }

  Future<bool> login(String email, String password) async {
    final url = Uri.parse(ApiConfig.loginEndpoint);

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': email,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final token = data['token'];

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('token', token);

      return true;
    } else {
      print('Error en login: ${response.body}');
      return false;
    }
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
  }

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }
}
