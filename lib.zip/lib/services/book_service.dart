import 'dart:convert';
import 'package:http/http.dart' as http;
import 'auth_service.dart';

class BookService {
  final String baseUrl = 'http://localhost:8080/api';

  Future<bool> addBook(String titulo, String autor) async {
    final token = await AuthService().getToken(); // Aquí obtienes el token

    final response = await http.post(
      Uri.parse('$baseUrl/libros'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({'titulo': titulo, 'autor': autor}),
    );

    return response.statusCode == 200 || response.statusCode == 201;
  }
}
