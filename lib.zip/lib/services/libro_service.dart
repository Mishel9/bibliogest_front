import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:bibliogestapp/config/api_config.dart';
import '../models/libro.dart';
import 'auth_service.dart';

class LibroService {
  final AuthService _authService = AuthService();

  Future<List<Libro>> getLibros() async {
    final token = await _authService.getToken();
    final response = await http.get(
      Uri.parse('${ApiConfig.baseUrl}/libros'),
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode == 200) {
      final List<dynamic> jsonData = jsonDecode(response.body);
      return jsonData.map((e) => Libro.fromJson(e)).toList();
    } else {
      throw Exception('Error al cargar los libros');
    }
  }
}
